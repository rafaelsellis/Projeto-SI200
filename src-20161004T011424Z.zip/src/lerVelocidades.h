// Le dados das velocidades da tabela de um arquivo


void LerVelocidades(char* nomeDoArquivo, ConjAmostras* saida){
	//TODO
	
}
