// Le dados da atenuação da tabela de um arquivo


void LerAtenuacao(char* nomeDoArquivo, ConjAmostras* saida){
	
	//TODO
}
