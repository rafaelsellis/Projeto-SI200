
#include <stdio.h>
#include <stdlib.h>

#include "registros.h"
#include "imprimir.h"
#include "calcularDesvioPadrao.h"
#include "lerAtenuacao.h"
#include "lerVelocidades.h"


int main(){
	Imprimir_Teste();
	//TODO
}
