// Funções para imprimir Registros


//...

void Imprimir_Teste(){
	printf("abc\n");
}

void printMedida(Medida * medida){
	printf("Atenuacao: %.3f Velocidade: %.3f ", medida->Atenua, medida->Veloc);
}

//TODO
