// Calcular Desvio Padrao

// #include <math.h>

//...

/// TODO
